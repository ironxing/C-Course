﻿namespace BookSerializer {
	public class BookList : SerializeableList<Book> { }
}
